package com.example.validator_lib

class DoubleValidatorText {
}